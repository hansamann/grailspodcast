class AuthenticationUrlMappings {
	static mappings = {
	  "/authentication/$action?/$id?"{
		  controller = 'authentication'
	  }
	}	
}
